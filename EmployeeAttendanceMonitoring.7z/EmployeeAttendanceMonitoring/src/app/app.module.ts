import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { AgGridModule} from 'ag-grid-angular/main';
import { HttpModule, Http } from '@angular/http';
import { AdminHomePageComponent } from './components/admin-home-page/admin-home-page.component'
import {Routes,RouterModule} from '@angular/router';
import { AdminstaffhomepageComponent } from './components/adminstaffhomepage/adminstaffhomepage.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { EmployeehomepageComponent } from './components/employeehomepage/employeehomepage.component';
const appRoutes:Routes=[

   { path: '',   redirectTo: '/home', pathMatch: 'full'},
   {path:'home',component:HomepageComponent},
   {path:'employee',component:EmployeehomepageComponent},
   {path:"admin",component:AdminHomePageComponent},
   {path:'adminStaff',component:AdminstaffhomepageComponent}
  // {path:'',component:AppComponent},
   //{path:'login/user',redirectTo:'/home',pathMatch:'full'},
  ]
@NgModule({
  declarations: [
    AppComponent,
    AdminHomePageComponent,
    AdminstaffhomepageComponent,
    HomepageComponent,
    EmployeehomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AgGridModule.withComponents([]),
    HttpModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
