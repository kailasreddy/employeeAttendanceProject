import { Component, OnInit,ViewChild } from '@angular/core';
import { AdminserviceService } from '../../services/adminservice.service';
import { error } from 'util';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import {NgForm} from '@angular/forms';
import { EmployeeLogin } from 'src/classes/EmployeeLogin';
@Component({
  selector: 'app-admin-home-page',
  templateUrl: './admin-home-page.component.html',
  styleUrls: ['./admin-home-page.component.css']
})
export class AdminHomePageComponent implements OnInit {
  @ViewChild('f',{static: false}) signupForm:NgForm;
  constructor(private _adminService:AdminserviceService) { }
    ListEmployees:EmployeeDetails[]=[];
    addEmployeeStatus="false";
  ngOnInit() {
    this.addEmployeeStatus="false";
    this._adminService.getAllEmployees().subscribe((data)=>{
     this.ListEmployees=data;
     console.log(data);
     console.log(this.ListEmployees);
    },error=>{
      console.log(error);
    })
  }
  
  delete(emp_id){
    console.log(emp_id);
    this._adminService.deleteEmployee(emp_id).subscribe((data)=>{
      console.log(data);
      this.ngOnInit();
    })
    
  }
  addEmployee(){
    this.addEmployeeStatus="true";

  }
  processForm(){
    console.log(this.signupForm.value);
    let emp=new EmployeeDetails();
    emp.name=this.signupForm.value.employeeData.name;
    console.log(emp.name);
    emp.designation=this.signupForm.value.employeeData.designation;
    emp.reportingTo=this.signupForm.value.employeeData.reportingTo;
    emp.userType=this.signupForm.value.employeeData.userType;
    emp.address=this.signupForm.value.employeeData.address;
    emp.gender=this.signupForm.value.employeeData.gender;
    emp.yearsOfService=this.signupForm.value.employeeData.yearsOfService;
    emp.bankAccount=this.signupForm.value.employeeData.bankAccount;
    emp.ctc=this.signupForm.value.employeeData.ctc;
    emp.leaves=this.signupForm.value.employeeData.leaves;
    console.log(emp);
    this._adminService.addEmployee(emp).subscribe((data)=>{
      console.log(data);
      alert(emp.userType+" Added Successfully...");
      
    })
  }

}
