import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { AdminstaffserviceService } from 'src/app/services/adminstaffservice.service';
import { stat } from 'fs';

@Component({
  selector: 'app-adminstaffhomepage',
  templateUrl: './adminstaffhomepage.component.html',
  styleUrls: ['./adminstaffhomepage.component.css']
})
export class AdminstaffhomepageComponent implements OnInit {
  id;
  employee=new EmployeeDetails();
  lop;
  constructor(private adminStaffService:AdminstaffserviceService) { }
  status="present";
  ngOnInit() {
  }
  findEmployee(){
    console.log(this.id);
    this.adminStaffService.findEmployee(this.id).subscribe((data)=>{
      console.log(data);
      this.employee=data;
      console.log(this.employee);
    })
    
  }
  submitAttendance(emp_id,status){
    console.log(emp_id);
    console.log(status);
    this.adminStaffService.submitAttendance(emp_id,status).subscribe((data)=>{
      console.log(data);
    })

  }
  lossOfPay(){
    console.log(this.id);
    this.adminStaffService.lop(this.id).subscribe((data)=>{
      console.log(data);
      this.lop=data;
    })

  }
}
