import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { UtilityserviceService } from 'src/app/services/utilityservice.service';
import * as CanvasJS from '../../canvasjs.min';
import { EmployeeserviceService } from 'src/app/services/employeeservice.service';
import { type } from 'os';
import { Attendance } from 'src/classes/Attendance';
@Component({
  selector: 'app-employeehomepage',
  templateUrl: './employeehomepage.component.html',
  styleUrls: ['./employeehomepage.component.css']
})
export class EmployeehomepageComponent implements OnInit {
  
   emp_id;
   empd=new EmployeeDetails();
   attendances;
   lop;
   datee;
   leaves;
   leaveStatus="";
    dataPoints=[{label:"Jan",y:70},{label:"Feb",y:70},{label:"Mar",y:70},{label:"Apr",y:70},{label:"May",y:70},{label:"Jun",y:70},{label:"Jul",y:70},{label:"Aug",y:70},{label:"Sep",y:70},
    {label:"Oct",y:70},{label:"Nov",y:70},{label:"Dec",y:70}]
  constructor(private utilityService:UtilityserviceService,private employeeService:EmployeeserviceService) { }

  ngOnInit() {
    this.leaveStatus="";
    let dataPoints = this.dataPoints
		
		let chart = new CanvasJS.Chart("chartContainer",{
			 animationEnabled: true,
			title:{
				text: "Attendance BarGraph"
			},
			data: [{
				type: "column",
				dataPoints : dataPoints
			}]
		});
		chart.render();
    
    this.emp_id=sessionStorage.getItem("emp_id");
    this.empd=this.utilityService.getEmployeeDetails();
    console.log(this.empd);

  }
  viewAttendance(){
       this.employeeService.viewAttendance(this.emp_id).subscribe((data)=>{
             this.attendances=data;
             console.log(this.attendances);
       })
  }
  checkLop(){
    this.employeeService.checkLop(this.emp_id).subscribe((data)=>{
       this.lop=data;
       console.log(this.lop);
    })
  }
  submitDate(){
  
    let newDate = new Date(this.datee);
    console.log(newDate);
    console.log(typeof this.datee);
     console.log(this.datee);
   
    let day=newDate.getDate();
    let month=newDate.getMonth()+1;
    let year=newDate.getFullYear();
    console.log(day+" "+month+" "+year);
    let attendance=new Attendance();
    attendance.day=day;
    attendance.month=month;
    attendance.year=year;
    attendance.status="leave";
    this.employeeService.applyLeave(this.emp_id,attendance).subscribe((data)=>{
      console.log(data);
      this.leaveStatus=data;
    })
    
  }
  checkAvailableLeaves(){
      this.employeeService.leaves(this.emp_id).subscribe((data)=>{
        this.leaves=data;
      })
  }

}
