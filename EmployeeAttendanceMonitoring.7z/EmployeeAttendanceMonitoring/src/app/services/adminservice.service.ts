import { Injectable } from '@angular/core';
import{Http, Response, Headers, RequestOptions} from '@angular/http';
import{Observable}   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {
  private baseUrl:string='http://localhost:8080/';
  private headers = new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});

   
  constructor(private _http:Http) { }
  getAllEmployees(){
    console.log("abc");
    return this._http.get(this.baseUrl+"allEmployees",this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
   
  }
  deleteEmployee(emp_id){
    return this._http.delete(this.baseUrl+"deleteEmployee/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
  }
  addEmployee(emp:EmployeeDetails){
    return this._http.put(this.baseUrl+"addEmployee",JSON.stringify(emp),this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
  }
  findEmployee(emp_id){
    return this._http.get(this.baseUrl+"findEmployee/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler)
  }
  errorHandler(error:Response){

    return Observable.throw(error||"SERVER ERROR");
 }
 
  loginValidation(emp_id,userType,password){
   return this._http.get(this.baseUrl+"loginValidation/"+emp_id+"/"+userType+"/"+password,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
  }
}
