import { Injectable } from '@angular/core';
import{Http, Response, Headers, RequestOptions} from '@angular/http';
import{Observable}   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { error } from 'protractor';
import { Attendance } from 'src/classes/Attendance';
@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {
  private baseUrl:string='http://localhost:8080/';
  private headers = new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});

  constructor(private _http:Http) { }
    
   viewAttendance(emp_id){
        return this._http.get(this.baseUrl+"viewAttendance/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
   }
   errorHandler(error:Response){

    return Observable.throw(error||"SERVER ERROR");
 }
 checkLop(emp_id){
        return this._http.get(this.baseUrl+"lop/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
 }  
   applyLeave(emp_id,attendance:Attendance){
     return this._http.put(this.baseUrl+"applyLeave/"+emp_id,JSON.stringify(attendance),this.options).map((response:Response)=>response.text()).catch(this.errorHandler);
   }
   leaves(emp_id){
     return this._http.get(this.baseUrl+"leaves/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
   }

}
