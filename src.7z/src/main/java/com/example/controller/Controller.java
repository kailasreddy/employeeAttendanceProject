package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Attendance;
import com.example.entities.EmployeeDetails;

import com.example.service.EmployeeDetailsService;

@RestController
@CrossOrigin(origins="http://localhost:4200", allowedHeaders="*")
public class Controller {
	@Autowired
	EmployeeDetailsService empdService;
@PutMapping("/addEmployee")
public EmployeeDetails addEmployee(@RequestBody EmployeeDetails emp) {
	emp.getCtc();
	
	return empdService.addEmployee(emp);
}
@GetMapping("/allEmployees")
public List<EmployeeDetails> getAllEmployees(){
    List<EmployeeDetails> list= empdService.getAllEmployees();	     
       System.out.println(list.get(0).getAddress());
       return list;
}
@DeleteMapping("/deleteEmployee/{emp_id}")
public int deleteEmployee(@PathVariable long emp_id) {
	 
       return empdService.deleteEmployee(emp_id);
}

@GetMapping("/findEmployee/{emp_id}")
public Optional<EmployeeDetails> findEmployee(@PathVariable long emp_id) {
  return empdService.findEmployee(emp_id);	      
}
@GetMapping("/submitAttendance/{emp_id}/{status}")
public int submitAttendance(@PathVariable long emp_id,@PathVariable String status) {
	return empdService.submitAttendance(emp_id, status);
			
}
@GetMapping("/lop/{emp_id}")
public float lop(@PathVariable long emp_id) {
	return empdService.lop(emp_id);
	
}

@GetMapping("/loginValidation/{emp_id}/{userType}/{password}")
public EmployeeDetails loginValidation(@PathVariable long emp_id,@PathVariable String userType,@PathVariable String password) {
   return empdService.loginValidation(emp_id, userType, password);
}

@GetMapping("viewAttendance/{emp_id}") 
public List<Attendance> viewAttendance(@PathVariable long emp_id){
	return empdService.viewAttendance(emp_id);
	
}
@PutMapping("/applyLeave/{emp_id}")
public String applyLeave(@PathVariable long emp_id,@RequestBody Attendance attendance) {
	
	return empdService.applyLeave(emp_id, attendance);
}
	
@GetMapping("/leaves/{emp_id}")
public int leaves(@PathVariable long emp_id) {
	return empdService.leaves(emp_id);
}

}
