package com.example.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.entities.Attendance;

public interface AttendanceRepositoy extends JpaRepository<Attendance, Long>{
	@Query("select a from Attendance a where a.employeeDetails.emp_id=:emp_id and a.month=:month and a.year=:year")
	List<Attendance> employeeAttendance(@Param("emp_id") long emp_id,@Param("month") int month,@Param("year") int year);

}
